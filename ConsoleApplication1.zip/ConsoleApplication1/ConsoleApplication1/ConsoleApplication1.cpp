﻿// ConsoleApplication1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <windows.h>
#include "include/glut.h"
#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

int mode;
double mx = 1;
GLfloat R = 5.0f;
GLfloat cx = 0, cy = 0, cz = 0; // для перемещения объекта
GLfloat lx = 0, ly = 0, lz = 0; // для перемещения источника света
GLfloat m[3];
static GLuint texture;

// Структура для заголовка BMP файла
#pragma pack(push, 1)
struct BMPHeader {
    char signature[2];
    int fileSize;
    int reserved;
    int dataOffset;
    int headerSize;
    int width;
    int height;
    short planes;
    short bitsPerPixel;
    int compression;
    int imageSize;
    int xPixelsPerM;
    int yPixelsPerM;
    int colorsUsed;
    int colorsImportant;
};
#pragma pack(pop)

// Функция загрузки BMP текстуры
GLuint LoadBMPTexture(const char* filename) {
    ifstream file(filename, ios::binary);
    if (!file.is_open()) {
        cout << "Failed to open texture file: " << filename << endl;
        return 0;
    }

    BMPHeader header;
    file.read(reinterpret_cast<char*>(&header), sizeof(BMPHeader));

    if (header.signature[0] != 'B' || header.signature[1] != 'M') {
        cout << "Not a valid BMP file: " << filename << endl;
        file.close();
        return 0;
    }

    if (header.bitsPerPixel != 24) {
        cout << "Only 24-bit BMP files are supported: " << filename << endl;
        file.close();
        return 0;
    }

    // Выделяем память для данных изображения
    unsigned char* data = new unsigned char[header.imageSize];
    file.seekg(header.dataOffset, ios::beg);
    file.read(reinterpret_cast<char*>(data), header.imageSize);
    file.close();

    // Создаем текстуру OpenGL
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    // Устанавливаем параметры текстуры
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    // Загружаем данные текстуры
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, header.width, header.height, 0,
        GL_BGR_EXT, GL_UNSIGNED_BYTE, data);

    // Освобождаем память
    delete[] data;

    return textureID;
}

/* рисование каркаса */
void Draw_carcas(float dB, float dL) {
    GLfloat x, y, z, B, L; // B - широта, L - долгота
    glColor3f(1, 0, 0);

    // рисуем по меридианам
    for (L = 0; L <= 360; L += dL) {
        glBegin(GL_LINE_STRIP);
        for (B = -90; B <= 90; B += dB) {
            x = R * cos(B * 3.14 / 180) * sin(L * 3.14 / 180) + cx;
            y = R * cos(B * 3.14 / 180) * cos(L * 3.14 / 180) + cy;
            z = R * sin(B * 3.14 / 180);
            if (B > 0) z += R * pow(B / 90.0, 4);
            z += cz;
            glVertex3d(x, y, z);
        }
        glEnd();
    }

    // рисуем по параллелям
    for (B = -90; B <= 90; B += dB) {
        glBegin(GL_LINE_STRIP);
        for (L = 0; L <= 360; L += dL) {
            x = R * cos(B * 3.14 / 180) * sin(L * 3.14 / 180) + cx;
            y = R * cos(B * 3.14 / 180) * cos(L * 3.14 / 180) + cy;
            z = R * sin(B * 3.14 / 180);
            if (B > 0) z += R * pow(B / 90.0, 4);
            z += cz;
            glVertex3d(x, y, z);
        }
        glEnd();
    }
}

/* рисование полигонов */
void polygon(int type, float dB, float dL) {
    GLfloat B, L, x[4], y[4], z[4], a[3], b[3];
    GLfloat ix = 0, iy = 0, iwx = 1 / (180 / dB), iwy = 1 / (360 / dL);

    for (B = -90; B < 90; B += dB) {
        for (L = 0; L <= 360; L += dL) {
            // Вершина 1
            x[0] = R * cos(B * 3.14 / 180) * sin(L * 3.14 / 180) + cx;
            y[0] = R * cos(B * 3.14 / 180) * cos(L * 3.14 / 180) + cy;
            z[0] = R * sin(B * 3.14 / 180);
            if (B > 0) z[0] += R * pow(B / 90.0, 4);
            z[0] += cz;

            // Вершина 2
            x[1] = R * cos((B + dB) * 3.14 / 180) * sin(L * 3.14 / 180) + cx;
            y[1] = R * cos((B + dB) * 3.14 / 180) * cos(L * 3.14 / 180) + cy;
            z[1] = R * sin((B + dB) * 3.14 / 180);
            if (B + dB > 0) z[1] += R * pow((B + dB) / 90.0, 4);
            z[1] += cz;

            // Вершина 3
            x[2] = R * cos((B + dB) * 3.14 / 180) * sin((L + dL) * 3.14 / 180) + cx;
            y[2] = R * cos((B + dB) * 3.14 / 180) * cos((L + dL) * 3.14 / 180) + cy;
            z[2] = R * sin((B + dB) * 3.14 / 180);
            if (B + dB > 0) z[2] += R * pow((B + dB) / 90.0, 4);
            z[2] += cz;

            // Вершина 4
            x[3] = R * cos(B * 3.14 / 180) * sin((L + dL) * 3.14 / 180) + cx;
            y[3] = R * cos(B * 3.14 / 180) * cos((L + dL) * 3.14 / 180) + cy;
            z[3] = R * sin(B * 3.14 / 180);
            if (B > 0) z[3] += R * pow(B / 90.0, 4);
            z[3] += cz;

            switch (type) {
            case 1: // Текстурирование
                glBegin(GL_POLYGON);
                glTexCoord2d(ix, iy);            glVertex3d(x[0], y[0], z[0]);
                glTexCoord2d(ix, iy + iwy);      glVertex3d(x[1], y[1], z[1]);
                glTexCoord2d(ix + iwx, iy + iwy);glVertex3d(x[2], y[2], z[2]);
                glTexCoord2d(ix + iwx, iy);      glVertex3d(x[3], y[3], z[3]);
                glEnd();
                break;

            case 2: // Освещение
                a[0] = x[1] - x[0];
                a[1] = y[1] - y[0];
                a[2] = z[1] - z[0];
                b[0] = x[2] - x[0];
                b[1] = y[2] - y[0];
                b[2] = z[2] - z[0];
                m[0] = a[1] * b[2] - a[2] * b[1];
                m[1] = a[0] * b[2] - a[2] * b[0];
                m[2] = a[0] * b[1] - a[1] * b[0];

                glColor3f(0.0, 1.0, 0.0);
                glBegin(GL_QUADS);
                glNormal3fv(m);
                glVertex3d(x[0], y[0], z[0]);
                glNormal3fv(m);
                glVertex3d(x[1], y[1], z[1]);
                glNormal3fv(m);
                glVertex3d(x[2], y[2], z[2]);
                glNormal3fv(m);
                glVertex3d(x[3], y[3], z[3]);
                glEnd();
                break;

            case 3: // Просто цвет
                glColor3f(0.0, 1.0, 0.0);
                glBegin(GL_POLYGON);
                glVertex3d(x[0], y[0], z[0]);
                glVertex3d(x[1], y[1], z[1]);
                glVertex3d(x[2], y[2], z[2]);
                glVertex3d(x[3], y[3], z[3]);
                glEnd();
                break;
            }
            ix += iwx;
        }
        iy += iwy;
        ix = 0;
    }
}

void display(void) {
    glEnable(GL_DEPTH_TEST);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glColor3f(1.0, 0.0, 0.0);
    glPushMatrix();

    GLfloat mat_specular[] = { 0.0, 0.0, 1.0, 1.0 };
    GLfloat mat_shininess[] = { 50.0 };
    GLfloat lpos0[] = { -5.0 + lx, -5.0 + ly, -5.0 + lz, 1.0 };

    glShadeModel(GL_SMOOTH);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
    glLightfv(GL_LIGHT0, GL_POSITION, lpos0);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_COLOR_MATERIAL);

    switch (mode) {
    case 0: // Каркас
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-15, 15, -15, 15, -25, 25);
        gluLookAt(0, 5, 0, 0, 1, 0, 0, 0, 1);
        glDisable(GL_LIGHTING);
        Draw_carcas(12, 12);
        break;

    case 1: // Цвет с освещением
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-15, 15, -15, 15, -25, 25);
        gluLookAt(0, 5, 0, 0, 1, 0, 0, 0, 1);
        glEnable(GL_NORMALIZE);
        polygon(2, 12, 12);
        break;

    case 2: // Цвет и каркас
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-15, 15, -15, 15, -25, 25);
        gluLookAt(0, 5, 0, 0, 1, 0, 0, 0, 1);
        glEnable(GL_NORMALIZE);
        polygon(2, 12, 12);
        Draw_carcas(12, 12);
        break;

    case 3: // Перспективная проекция
        glDisable(GL_LIGHTING);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(50, 1, 1, 400);
        gluLookAt(0, 30, 0, 0, 0, 0, 0, 0, 1);
        glRotatef(20, 0, 1, 0);
        glRotatef(-27, 1, 0, 0);
        glRotatef(37, 0, 0, 1);
        Draw_carcas(12, 12);
        break;

    case 4: // Аксонометрическая проекция
        glDisable(GL_LIGHTING);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-15, 15, -15, 15, 25, -25);
        gluLookAt(0, 5, 0, 0, 0, 0, 0, 0, 1);
        glRotatef(45, 0, 0, 1);
        glRotatef(30, 1, 0, 0);
        Draw_carcas(12, 12);
        glDisable(GL_DEPTH_TEST);
        break;

    case 5: // Текстурирование
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-15, 15, -15, 15, -25, 25);
        gluLookAt(0, 5, 0, 0, 1, 0, 0, 0, 1);
        glEnable(GL_NORMALIZE);
        glEnable(GL_TEXTURE_2D);
        glColor3d(1, 0, 0);
        glBindTexture(GL_TEXTURE_2D, texture);
        polygon(1, 12, 12);
        glDisable(GL_TEXTURE_2D);
        break;

    default:
        glDisable(GL_LIGHTING);
        mode = 0;
        break;
    }

    glPopMatrix();
    glFlush();
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
    case '0': mode = 0; break;
    case '1': mode = 1; break;
    case '2': mode = 2; break;
    case '3': mode = 3; break;
    case '4': mode = 4; break;
    case '5': mode = 5; break;
    case 'w': cz += 0.1; break;
    case 's': cz -= 0.1; break;
    case 'a': cx += 0.1; break;
    case 'd': cx -= 0.1; break;
    case 'q': cy -= 0.1; break;
    case 'e': cy += 0.1; break;
    case 'j': lx -= 0.5; break;
    case 'l': lx += 0.5; break;
    case 'u': lz += 0.5; break;
    case 'o': lz -= 0.5; break;
    case 'i': ly += 0.5; break;
    case 'k': ly -= 0.5; break;
    case 'm': mx = (mx == 1) ? 5 : 1; break;
    case 'r': cx = cy = cz = 0; break;
    }
    glutPostRedisplay();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(700, 700);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("3D Модель Капли");
    glShadeModel(GL_SMOOTH);

    // Загрузка текстуры (укажите путь к вашему BMP файлу)
    texture = LoadBMPTexture("texture.bmp");
    if (!texture) {
        cout << "Failed to load texture. Using color mode instead." << endl;
    }

    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
